from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def helloworld(request):
    return HttpResponse("Hello World this is my first application in django")

def myapplication(request):
   return render(request, 'home.html')

def about(request):
   print(request)
   return render(request, 'about.html')

from .models import Student

def student_form(request):
    print(request)
    if request.method == "POST":

        student_name = request.POST.get('name')
        student_email = request.POST.get('email')
        student_age = request.POST.get('age')

        Student.objects.create(
            name=student_name,
            email=student_email,
            age=student_age
        )

        return render(request, 'success.html')

    return render(request, 'student.html')
