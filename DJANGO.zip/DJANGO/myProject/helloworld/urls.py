from django.urls import path
from . import views

urlpatterns=[
    path("hello/", views.helloworld),
    path("home/", views.myapplication),
    path("about/", views.about),
    path('student/', views.student_form),
]